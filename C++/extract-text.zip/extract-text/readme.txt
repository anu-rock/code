WAP to identify characters in the huge mess of text in the file "in.txt", such that:

One small letter is surrounded by EXACTLY three big bodyguards (capital letters) on each of its sides.
