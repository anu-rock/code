#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
	char data[100];
	//data = new char[100];
	int count = 0;
	int n0, n1, n2, n3, n4, n5, n6;
	string line;
	size_t i;
	ifstream myfile("in.txt");
	if(myfile.is_open())
	{
		while (!myfile.eof())
		{
			getline(myfile,line); //input text line-by-line
			for(i=3; i<=(line.length()-4); i++)
			{
				n0 = int(line[i]);
				n1 = int(line[i-3]);
				n2 = int(line[i-2]);
				n3 = int(line[i-1]);
				n4 = int(line[i+1]);
				n5 = int(line[i+2]);
				n6 = int(line[i+3]);
				//make a check to see if there are 3 capital letters on the left and right of a small letter
				if((n0>=97)&&(n0<=122)&&((n1,n2,n3,n4,n5,n6)>=65)&&((n1,n2,n3,n4,n5,n6)<=90))
				{
					data[count] = line[i]; //we store each found character (acc to given condition) in an array
					data[count+1] = '\0'; //make sure that the end of the array is a null character
					++count;
				}
			}
		}
		myfile.close();
	}
	else
		cout <<"Unable to open file"; 
	cout<<"Extracted text:"<<endl<<endl;
	for(int j=0; data[j]!='\0'; j++)
		cout<<data[j];
	cout<<"\n\n";
	return 0;
}

